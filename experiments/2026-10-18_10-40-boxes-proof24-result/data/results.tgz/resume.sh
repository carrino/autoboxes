#!/usr/bin/env bash
set -euo pipefail
cd /home/carrino/autoboxes
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
uv run python -u /home/carrino/autoboxes/experiments/2026-10-17_14-14-boxes-proof-overnight/overnight.py --resume /home/carrino/autoboxes/experiments/2026-10-08_14-42-boxes-3x3-loop/logs/5x5-proof34-a6gdsd3i
