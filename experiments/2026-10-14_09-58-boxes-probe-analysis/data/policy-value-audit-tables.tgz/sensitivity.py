"""Independent aggregation; no inference, fitting, or solving."""
import csv
import hashlib
import json
from pathlib import Path

import numpy as np

SOURCE = Path('/workspace/work/policy-value-audit-20261014')
OUT = Path('/workspace/work/policy-value-audit-review')
SEED = 20261014
RESAMPLES = 10000

def read_csv(name):
    with (SOURCE / name).open() as f:
        return list(csv.DictReader(f))

children = read_csv('children.csv')
ranking = read_csv('ranking.csv')
excluded = sorted({int(r['position']) for r in children
                   if int(r['undrawn_after']) <= 30})
assert {int(r['position']) for r in children if r['checkpoint'] == 'iter0'
        and int(r['undrawn_after']) <= 30} == set(excluded)
assert {int(r['position']) for r in children if r['checkpoint'] == 'iter22'
        and int(r['undrawn_after']) <= 30} == set(excluded)

def bootstrap(reference, candidate, metric):
    candidate_by = {r['position']: r for r in candidate}
    pairs = [(r, candidate_by[r['position']]) for r in reference]
    pairs = [(a, b) for a, b in pairs
             if np.isfinite(float(a[metric])) and np.isfinite(float(b[metric]))]
    families = sorted({a['family'] for a, _ in pairs})
    changes_by_family = [[float(b[metric]) - float(a[metric])
                          for a, b in pairs if a['family'] == family]
                         for family in families]
    sums = np.array([sum(x) for x in changes_by_family])
    counts = np.array([len(x) for x in changes_by_family])
    draws = np.random.default_rng(SEED).integers(
        len(families), size=(RESAMPLES, len(families)))
    samples = sums[draws].sum(axis=1) / counts[draws].sum(axis=1)
    return dict(reference_mean=float(np.mean([float(a[metric]) for a, _ in pairs])),
                candidate_mean=float(np.mean([float(b[metric]) for _, b in pairs])),
                delta=float(sums.sum() / counts.sum()),
                ci95_low=float(np.quantile(samples, .025)),
                ci95_high=float(np.quantile(samples, .975)),
                roots=len(pairs), families=len(families))

out = dict(scope='Inference-output sensitivity only; no inference, fitting, or solving',
           exclusion='Remove whole roots if any legal child collapses to <=30 undrawn edges',
           excluded_roots=excluded, excluded_count=len(excluded),
           solver_zone_children=sum(r['checkpoint'] == 'iter0'
                                    and int(r['undrawn_after']) <= 30 for r in children),
           bootstrap=dict(seed=SEED, resamples=RESAMPLES,
                          unit='source family', statistic='root-weighted paired mean'),
           source_sha256={name: hashlib.sha256((SOURCE / name).read_bytes()).hexdigest()
                          for name in ['summary.json', 'children.csv', 'ranking.csv']},
           comparisons=[])
for subset in ['all_roots', 'exclude_solver_roots']:
    rows = [r for r in ranking if subset == 'all_roots'
            or int(r['position']) not in excluded]
    for band in ['35..36', '37..38', 'all']:
        for mode in ['search', 'raw']:
            for predictor in ['margin', 'win', 'utility']:
                selected = [r for r in rows if (band == 'all' or r['band'] == band)
                            and r['mode'] == mode and r['predictor'] == predictor]
                reference = [r for r in selected if r['checkpoint'] == 'iter0']
                candidate = [r for r in selected if r['checkpoint'] == 'iter22']
                for metric in ['argmax_regret', 'pairwise_accuracy', 'spearman']:
                    out['comparisons'].append(dict(subset=subset, band=band, mode=mode,
                                                    predictor=predictor, metric=metric,
                                                    **bootstrap(reference, candidate, metric)))
(OUT / 'solver-zone-sensitivity.json').write_text(json.dumps(out, indent=2) + '\n')
print('Excluded', excluded, 'solver-zone children', out['solver_zone_children'])
for r in out['comparisons']:
    if r['mode'] == 'search' and r['predictor'] == 'margin' and r['band'] == '35..36':
        print(r)
